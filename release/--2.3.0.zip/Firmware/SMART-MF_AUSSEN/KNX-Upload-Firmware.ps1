../../data/KNX-Upload-Firmware-Generic.ps1 firmware-SMART-MF_AUSSEN.uf2
