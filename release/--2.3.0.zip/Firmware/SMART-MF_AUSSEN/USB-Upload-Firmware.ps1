../../data/Upload-Firmware-Generic-RP2040.ps1 firmware-SMART-MF_AUSSEN.uf2
